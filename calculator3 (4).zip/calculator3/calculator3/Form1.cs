﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculator3
{
    public partial class Form1 : Form
    {
        Double resultValues = 0;
        string operationPerformed = "";
        bool isOperationPerformed = false;
        public Form1()
        {
            InitializeComponent();
           this.KeyPress +=new KeyPressEventHandler(Form1_KeyPress);
            this.KeyPress +=new KeyPressEventHandler(txtresult_KerPress);
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_click(object sender, EventArgs e)
        {
            if ((txtresult.Text == "0") || isOperationPerformed)
                txtresult.Clear();
            isOperationPerformed = false;
            Button button = (Button)sender;
            if (button.Text == ".")
            {
                if (!txtresult.Text.Contains("."))
            {
                txtresult.Text = txtresult.Text + button.Text;
            }
            
            }
            else
            txtresult.Text = txtresult.Text +button.Text;
        }

        private void operator_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            if (resultValues != 0)
            {
                btnequal.PerformClick();
                operationPerformed = button.Text;
                lblCurrentOperation.Text = resultValues + " " + operationPerformed;
                isOperationPerformed = true;

            }
            else
            {
                operationPerformed = button.Text;
                resultValues = Double.Parse(txtresult.Text);
                lblCurrentOperation.Text = resultValues + " " + operationPerformed;
                isOperationPerformed = true;
            } 
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtresult.Text = "0";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            txtresult.Text = "0";
            resultValues = 0;
        }

        private void btnequal_Click(object sender, EventArgs e)
        {
            switch (operationPerformed)
            {
                case"+":
                txtresult.Text=(resultValues+Double.Parse(txtresult.Text)).ToString();
                    break;
                case "-":
                    txtresult.Text = (resultValues - Double.Parse(txtresult.Text)).ToString();
                    break;
                case "*":
                    txtresult.Text = (resultValues * Double.Parse(txtresult.Text)).ToString();
                    break;
                case "/":
                    txtresult.Text = (resultValues / Double.Parse(txtresult.Text)).ToString();
                    break;
                default:
                    break;
            }
            resultValues = Double.Parse(txtresult.Text);
            lblCurrentOperation.Text = "";
        }

        

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
          /*   if (e.KeyChar == (char)Keys.Enter)
            {
                resultValues = Double.Parse(txtresult.Text);
            }*/
          
        }

        private void txtresult_KerPress(object sender, KeyPressEventArgs e)
        {
           /* switch (e.KeyChar.ToString())
            {
                case "0":
                    zeroButton.PerformClick();
                    break;

                case "1":
                    oneButton.PerformClick();
                    break;

                case "2":
                    twoButton.PerformClick();
                    break;

                case "3":
                    threeButton.PerformClick();
                    break;

                case "4":
                    fourButton.PerformClick();
                    break;

                case "5":
                    fiveButton.PerformClick();
                    break;

                case "6":
                    sixButton.PerformClick();
                    break;

                case "7":
                    sevenButton.PerformClick();
                    break;

                case "8":
                    eightButton.PerformClick();
                    break;

                case "9":
                    nineButton.PerformClick();
                    break;

                case ".":
                    periodButton.PerformClick();
                    break;

                case "/":
                    divideButton.PerformClick();
                    break;

                case "*":
                    multiplicationButton.PerformClick();
                    break;

                case "-":
                    subtractButton.PerformClick();
                    break;

                case "+":
                    additionButton.PerformClick();
                    break;

                case "=":
                    btnequal.PerformClick();
                    break;

                default:
                     
                    break;
            }*/
          /*  if (e.KeyChar == (char)Keys.Enter)
            {
                resultValues = Double.Parse(txtresult.Text);
            }*/
           /* if (e.KeyChar == 13)
            {
                txtresult.Text = resultValues + " " + operationPerformed;
            }*/
        }

        private void txtresult_KeyDown(object sender, KeyEventArgs e)
        {
           /* if (e.KeyCode == Keys.Enter)
            {
                resultValues = Double.Parse(txtresult.Text);
            }*/
        }

        private void txtresult_KeyUp(object sender, KeyEventArgs e)
        {
           /* if (e.KeyCode == Keys.Enter)
            {
                resultValues = Double.Parse(txtresult.Text);
            }*/
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            
                MessageBox.Show("true");
            
        }

    }


}
